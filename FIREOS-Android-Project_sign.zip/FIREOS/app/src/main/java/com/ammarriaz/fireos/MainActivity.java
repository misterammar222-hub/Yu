package com.ammarriaz.fireos;

import android.os.Bundle;
import android.os.Handler;
import android.text.format.DateFormat;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Date;

/** The FIREOS home screen: animated background, clock and four big tiles. */
public class MainActivity extends BaseActivity {
    private TextView clock;
    private final Handler hd = new Handler();
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            clock.setText(DateFormat.format("h:mm a", new Date()));
            hd.postDelayed(this, 15000);
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        FrameLayout root = new FrameLayout(this);
        root.setClipChildren(false);
        root.addView(new EmberView(this), new FrameLayout.LayoutParams(-1, -1));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.BOTTOM);
        TextView logo = Ui.text(this, "FIREOS", 62, Ui.EMBER, true);
        TextView by = Ui.text(this, "by Ammar Riaz", 22, Ui.MUTED, false);
        by.setPadding(Ui.px(18), 0, 0, Ui.px(12));
        head.addView(logo);
        head.addView(by);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.LEFT);
        hp.setMargins(Ui.px(60), Ui.px(34), 0, 0);
        root.addView(head, hp);
        Fx.enter(head, 0);

        clock = Ui.text(this, "", 34, Ui.TEXT, false);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.RIGHT);
        cp.setMargins(0, Ui.px(50), Ui.px(60), 0);
        root.addView(clock, cp);

        final Class<?>[] to = {YouTubeActivity.class, LiveTvActivity.class, GamesActivity.class, SettingsActivity.class};
        String[] names = {"YouTube", "Live TV", "Games", "Settings"};
        String[] subs = {"Search and watch", "Free IPTV channels", "Snake, 2048, Pong", "Keys and playlists"};
        int[] top = {0xFFFF5A45, 0xFF3D8BFF, 0xFF35C98A, 0xFF8C78B8};
        int[] bot = {0xFFB3151C, 0xFF1A44A8, 0xFF16764F, 0xFF4A3B6B};
        int[] icon = {Icons.PLAY, Icons.TV, Icons.PAD, Icons.GEAR};

        LinearLayout row = new LinearLayout(this);
        row.setClipChildren(false);
        row.setGravity(Gravity.CENTER);
        for (int i = 0; i < 4; i++) {
            final int n = i;
            Tile t = new Tile(this, names[i], subs[i], top[i], bot[i], icon[i]);
            t.setOnClickListener(v -> go(to[n]));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.px(250), Ui.px(320));
            lp.setMargins(Ui.px(20), 0, Ui.px(20), 0);
            row.addView(t, lp);
            Fx.enter(t, 200 + i * 120);
        }
        root.addView(row, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));

        TextView hint = Ui.text(this, "Arrows to move, OK to open, Back to leave", 22, Ui.MUTED, false);
        FrameLayout.LayoutParams hl = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        hl.setMargins(0, 0, 0, Ui.px(34));
        root.addView(hint, hl);
        Fx.enter(hint, 900);

        setContentView(root);
        row.getChildAt(0).requestFocus();
    }

    @Override protected void onResume() {
        super.onResume();
        hd.post(tick);
    }

    @Override protected void onPause() {
        super.onPause();
        hd.removeCallbacks(tick);
    }
}
