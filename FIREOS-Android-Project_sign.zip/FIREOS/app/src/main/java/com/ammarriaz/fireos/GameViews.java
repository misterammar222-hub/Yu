package com.ammarriaz.fireos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

/** Base for the games: a timer loop, D-pad input (0 left, 1 right, 2 up, 3 down) and a shared look. */
abstract class GameView extends View {
    private final Handler hd = new Handler();
    private final int period;
    private boolean run;
    private LinearGradient bgShader;
    protected final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    protected final RectF r = new RectF();
    protected int score;

    private final Runnable loop = new Runnable() {
        @Override public void run() {
            if (!run) return;
            tick();
            invalidate();
            hd.postDelayed(this, period);
        }
    };

    GameView(Context c, int period) {
        super(c);
        this.period = period;
        setFocusable(true);
        setFocusableInTouchMode(true);
    }

    void start() {
        if (run) return;
        run = true;
        requestFocus();
        hd.post(loop);
    }

    void stop() {
        run = false;
        hd.removeCallbacks(loop);
    }

    abstract String title();
    abstract void tick();
    abstract void restart();
    abstract void key(int dir);
    abstract void render(Canvas c, int w, int h);

    /** Whether holding a direction key repeats the move. */
    boolean repeats() { return true; }

    /** A square play area under the title: {left, top, side}. */
    protected float[] square(int w, int h) {
        float room = h - Ui.px(150);
        float side = Math.min(w * 0.9f, room);
        return new float[]{(w - side) / 2f, Ui.px(84) + (room - side) / 2f, side};
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        bgShader = new LinearGradient(0, 0, 0, h, 0xFF150F20, 0xFF2B1018, Shader.TileMode.CLAMP);
    }

    @Override protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        p.setStyle(Paint.Style.FILL);
        p.setShader(bgShader);
        c.drawRect(0, 0, w, h, p);
        p.setShader(null);
        render(c, w, h);
        p.setStyle(Paint.Style.FILL);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(Ui.px(40));
        p.setColor(Ui.AMBER);
        c.drawText(title(), w / 2f, Ui.px(58), p);
        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(Ui.px(22));
        p.setColor(Ui.MUTED);
        c.drawText("Arrows move    OK restarts    Back leaves", w / 2f, h - Ui.px(24), p);
    }

    @Override public boolean onKeyDown(int k, KeyEvent e) {
        int d = k == KeyEvent.KEYCODE_DPAD_LEFT ? 0 : k == KeyEvent.KEYCODE_DPAD_RIGHT ? 1
                : k == KeyEvent.KEYCODE_DPAD_UP ? 2 : k == KeyEvent.KEYCODE_DPAD_DOWN ? 3 : -1;
        if (d >= 0) {
            if (e.getRepeatCount() == 0 || repeats()) key(d);
            return true;
        }
        if (k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER) {
            restart();
            return true;
        }
        return super.onKeyDown(k, e);
    }
}

/** Snake. The board wraps around, so there are no walls. */
final class SnakeView extends GameView {
    private static final int N = 20;
    private final ArrayList<int[]> s = new ArrayList<int[]>();
    private final Random rnd = new Random();
    private int dx, dy, ndx, ndy, fx, fy, t;

    SnakeView(Context c) {
        super(c, 40);
        restart();
    }

    @Override String title() { return "Snake   " + score; }

    @Override void restart() {
        s.clear();
        s.add(new int[]{10, 10});
        s.add(new int[]{9, 10});
        s.add(new int[]{8, 10});
        dx = ndx = 1;
        dy = ndy = 0;
        score = 0;
        food();
    }

    private boolean hit(int x, int y) {
        for (int[] q : s) {
            if (q[0] == x && q[1] == y) return true;
        }
        return false;
    }

    private void food() {
        do {
            fx = rnd.nextInt(N);
            fy = rnd.nextInt(N);
        } while (hit(fx, fy));
    }

    @Override void key(int d) {
        int a = d == 0 ? -1 : d == 1 ? 1 : 0;
        int b = d == 2 ? -1 : d == 3 ? 1 : 0;
        if (a + dx != 0 || b + dy != 0) {
            ndx = a;
            ndy = b;
        }
    }

    @Override void tick() {
        if (++t % 3 != 0) return;
        dx = ndx;
        dy = ndy;
        int x = (s.get(0)[0] + dx + N) % N, y = (s.get(0)[1] + dy + N) % N;
        if (hit(x, y)) {
            restart();
            return;
        }
        s.add(0, new int[]{x, y});
        if (x == fx && y == fy) {
            score++;
            food();
        } else {
            s.remove(s.size() - 1);
        }
    }

    @Override void render(Canvas c, int w, int h) {
        float[] a = square(w, h);
        float ox = a[0], oy = a[1], side = a[2], cell = side / N;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF1B1428);
        r.set(ox, oy, ox + side, oy + side);
        c.drawRoundRect(r, cell, cell, p);
        float pulse = 1f + 0.15f * (float) Math.sin(SystemClock.uptimeMillis() / 140.0);
        p.setColor(0xFFFF4D2E);
        c.drawCircle(ox + (fx + 0.5f) * cell, oy + (fy + 0.5f) * cell, cell * 0.38f * pulse, p);
        for (int i = s.size() - 1; i >= 0; i--) {
            int[] q = s.get(i);
            p.setColor(i == 0 ? 0xFFB8F5C8 : 0xFF45C98A);
            r.set(ox + q[0] * cell + 1.5f, oy + q[1] * cell + 1.5f,
                    ox + (q[0] + 1) * cell - 1.5f, oy + (q[1] + 1) * cell - 1.5f);
            c.drawRoundRect(r, cell * 0.3f, cell * 0.3f, p);
        }
    }
}

/** 2048 with a small "pop" animation on new and merged tiles. */
final class Game2048View extends GameView {
    private static final int[] COL = new int[18];

    static {
        COL[0] = 0xFF2A2040;
        for (int i = 1; i < 18; i++) {
            COL[i] = Color.HSVToColor(new float[]{(i * 34 + 8) % 360, 0.72f, 0.92f});
        }
    }

    private final int[] b = new int[16];
    private final long[] born = new long[16];
    private final Random rnd = new Random();
    private boolean over;

    Game2048View(Context c) {
        super(c, 33);
        restart();
    }

    @Override String title() { return "2048   " + score; }

    @Override boolean repeats() { return false; }

    @Override void restart() {
        Arrays.fill(b, 0);
        score = 0;
        over = false;
        add();
        add();
    }

    private void add() {
        int n = 0;
        for (int i = 0; i < 16; i++) {
            if (b[i] == 0) n++;
        }
        if (n == 0) return;
        int k = rnd.nextInt(n);
        for (int i = 0; i < 16; i++) {
            if (b[i] == 0 && k-- == 0) {
                b[i] = rnd.nextInt(10) == 0 ? 4 : 2;
                born[i] = SystemClock.uptimeMillis();
                return;
            }
        }
    }

    private boolean stuck() {
        for (int i = 0; i < 16; i++) {
            if (b[i] == 0) return false;
            if (i % 4 < 3 && b[i] == b[i + 1]) return false;
            if (i < 12 && b[i] == b[i + 4]) return false;
        }
        return true;
    }

    @Override void key(int d) {
        if (over) return;
        boolean moved = false;
        long now = SystemClock.uptimeMillis();
        for (int a = 0; a < 4; a++) {
            int[] idx = new int[4];
            for (int j = 0; j < 4; j++) {
                idx[j] = d == 0 ? a * 4 + j : d == 1 ? a * 4 + 3 - j : d == 2 ? j * 4 + a : (3 - j) * 4 + a;
            }
            int[] l = new int[4];
            boolean[] merged = new boolean[4];
            int m = 0;
            for (int j = 0; j < 4; j++) {
                if (b[idx[j]] != 0) l[m++] = b[idx[j]];
            }
            for (int j = 0; j < m - 1; j++) {
                if (l[j] == l[j + 1]) {
                    l[j] *= 2;
                    score += l[j];
                    merged[j] = true;
                    for (int q = j + 1; q < m - 1; q++) l[q] = l[q + 1];
                    l[m - 1] = 0;
                    m--;
                }
            }
            for (int j = 0; j < 4; j++) {
                if (b[idx[j]] != l[j]) {
                    moved = true;
                    b[idx[j]] = l[j];
                }
                if (merged[j]) born[idx[j]] = now;
            }
        }
        if (moved) {
            add();
            over = stuck();
        }
    }

    @Override void tick() {
        // nothing to update: the view just redraws so the pop animation plays
    }

    @Override void render(Canvas c, int w, int h) {
        float[] a = square(w, h);
        float ox = a[0], oy = a[1], side = a[2];
        float gap = side * 0.025f, cell = (side - gap * 5) / 4f;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF1B1428);
        r.set(ox, oy, ox + side, oy + side);
        c.drawRoundRect(r, gap * 2, gap * 2, p);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        long now = SystemClock.uptimeMillis();
        for (int i = 0; i < 16; i++) {
            float x = ox + gap + (i % 4) * (cell + gap);
            float y = oy + gap + (i / 4) * (cell + gap);
            int v = b[i];
            if (v == 0) {
                p.setColor(COL[0]);
                r.set(x, y, x + cell, y + cell);
                c.drawRoundRect(r, gap, gap, p);
                continue;
            }
            float t = Math.min(1f, (now - born[i]) / 170f);
            float sc = 0.6f + 0.4f * (1f - (1f - t) * (1f - t));
            float half = cell / 2f * sc, cx = x + cell / 2f, cy = y + cell / 2f;
            p.setColor(COL[Math.min(17, Integer.numberOfTrailingZeros(v))]);
            r.set(cx - half, cy - half, cx + half, cy + half);
            c.drawRoundRect(r, gap, gap, p);
            p.setColor(0xFFFFFFFF);
            p.setTextSize(cell * sc * (v < 100 ? 0.45f : v < 1000 ? 0.36f : 0.28f));
            c.drawText(String.valueOf(v), cx, cy + p.getTextSize() * 0.35f, p);
        }
        if (over) {
            p.setColor(0xB0150F20);
            r.set(ox, oy, ox + side, oy + side);
            c.drawRoundRect(r, gap * 2, gap * 2, p);
            p.setColor(0xFFFFB347);
            p.setTextSize(side * 0.09f);
            c.drawText("Game over. Press OK", ox + side / 2f, oy + side / 2f, p);
        }
    }
}

/** Pong against the CPU: Up and Down move your paddle (the left one). */
final class PongView extends GameView {
    private final Random rnd = new Random();
    private float py = 110, cy = 110, bx, by, vx, vy;
    private int ps, cs;

    PongView(Context c) {
        super(c, 25);
        restart();
    }

    @Override String title() { return "Pong   You " + ps + " : " + cs + " CPU"; }

    private void serve(int d) {
        bx = 200;
        by = 150;
        vx = 4.2f * d;
        vy = (rnd.nextFloat() - 0.5f) * 5f;
    }

    @Override void restart() {
        ps = cs = 0;
        py = cy = 110;
        serve(1);
    }

    @Override void key(int d) {
        if (d == 2) py = Math.max(0f, py - 26f);
        if (d == 3) py = Math.min(220f, py + 26f);
    }

    @Override void tick() {
        bx += vx;
        by += vy;
        if (by < 6f || by > 294f) {
            vy = -vy;
            by = Math.max(6f, Math.min(294f, by));
        }
        cy += Math.max(-3.2f, Math.min(3.2f, by - cy - 40f));
        cy = Math.max(0f, Math.min(220f, cy));
        if (vx < 0 && bx < 24 && bx > 6 && by > py - 5 && by < py + 85) {
            vx = Math.min(10f, -vx * 1.06f);
            vy = Math.max(-7f, Math.min(7f, vy + (by - py - 40f) / 9f));
        }
        if (vx > 0 && bx > 376 && bx < 394 && by > cy - 5 && by < cy + 85) {
            vx = -Math.min(10f, vx * 1.06f);
        }
        if (bx < 0) {
            cs++;
            serve(1);
        }
        if (bx > 400) {
            ps++;
            serve(-1);
        }
    }

    @Override void render(Canvas c, int w, int h) {
        float room = h - Ui.px(150);
        float s = Math.min(w * 0.9f / 400f, room / 300f);
        float ox = (w - 400 * s) / 2f, oy = Ui.px(84) + (room - 300 * s) / 2f;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF1B1428);
        r.set(ox, oy, ox + 400 * s, oy + 300 * s);
        c.drawRoundRect(r, 14 * s, 14 * s, p);
        p.setColor(0x33FFFFFF);
        for (int j = 0; j < 300; j += 24) {
            c.drawRect(ox + 198 * s, oy + j * s, ox + 202 * s, oy + (j + 12) * s, p);
        }
        p.setColor(0xFFFFB347);
        r.set(ox + 10 * s, oy + py * s, ox + 18 * s, oy + (py + 80) * s);
        c.drawRoundRect(r, 4 * s, 4 * s, p);
        p.setColor(0xFFFF6A1A);
        r.set(ox + 382 * s, oy + cy * s, ox + 390 * s, oy + (cy + 80) * s);
        c.drawRoundRect(r, 4 * s, 4 * s, p);
        p.setColor(0xFFFFFFFF);
        c.drawCircle(ox + bx * s, oy + by * s, 6 * s, p);
    }
}
