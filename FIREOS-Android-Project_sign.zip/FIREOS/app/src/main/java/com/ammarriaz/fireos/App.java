package com.ammarriaz.fireos;

import android.app.Application;

public class App extends Application {
    @Override public void onCreate() {
        super.onCreate();
        Prefs.init(this);
    }
}
