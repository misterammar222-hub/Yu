package com.ammarriaz.fireos;

import android.content.Intent;
import android.os.Bundle;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;

/** Pick a free IPTV list, then pick a channel. Lists come from the open iptv-org project. */
public class LiveTvActivity extends BaseActivity {
    private static final String[][] CATS = {
            {"News", "categories/news"}, {"Sports", "categories/sports"}, {"Movies", "categories/movies"},
            {"Entertainment", "categories/entertainment"}, {"Kids", "categories/kids"},
            {"Music", "categories/music"}, {"Documentary", "categories/documentary"},
            {"Pakistan", "countries/pk"}, {"India", "countries/in"}, {"USA", "countries/us"},
            {"UK", "countries/uk"}, {"My own playlist", ""}
    };

    private ListView lv;
    private TextView title, status;
    private TextAdapter ad;
    private final ArrayList<String> labels = new ArrayList<String>();
    private boolean inChannels;
    private int req, lastCat;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(Ui.px(70), Ui.px(40), Ui.px(70), Ui.px(30));
        title = Ui.text(this, "Live TV", 52, Ui.EMBER, true);
        status = Ui.text(this, "", 24, Ui.MUTED, false);
        status.setPadding(0, Ui.px(4), 0, Ui.px(16));
        lv = new ListView(this);
        lv.setDivider(null);
        lv.setDividerHeight(Ui.px(6));
        lv.setCacheColorHint(0);
        lv.setSelector(R.drawable.sel_fill);
        lv.setVerticalScrollBarEnabled(false);
        ad = new TextAdapter(this, labels);
        lv.setAdapter(ad);
        if (Prefs.anim()) {
            lv.setLayoutAnimation(new LayoutAnimationController(AnimationUtils.loadAnimation(this, R.anim.slide_in), 0.1f));
        }
        lv.setOnItemClickListener((parent, view, pos, id) -> {
            if (inChannels) play(pos);
            else load(pos);
        });
        root.addView(title);
        root.addView(status);
        root.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
        showCats();
    }

    private void refresh(int select) {
        ad.notifyDataSetChanged();
        lv.setSelection(select);
        if (Prefs.anim()) lv.scheduleLayoutAnimation();
        lv.requestFocus();
    }

    private void showCats() {
        req++;
        inChannels = false;
        title.setText("Live TV");
        status.setText("Choose a channel list");
        labels.clear();
        for (String[] c : CATS) labels.add(c[0]);
        refresh(lastCat);
    }

    private void load(int pos) {
        lastCat = pos;
        String path = CATS[pos][1];
        final String url = path.length() > 0 ? "https://iptv-org.github.io/iptv/" + path + ".m3u" : Prefs.playlist().trim();
        if (url.length() == 0) {
            status.setText("Add your playlist link in Settings first");
            return;
        }
        title.setText(CATS[pos][0]);
        status.setText("Loading channels...");
        final int my = ++req;
        new Thread(() -> {
            try {
                final ArrayList<Item> items = M3u.parse(Net.get(url), 400);
                runOnUiThread(() -> {
                    if (my == req && !isFinishing()) show(items);
                });
            } catch (final Exception e) {
                runOnUiThread(() -> {
                    if (my == req && !isFinishing()) {
                        status.setText("Could not load the list (" + e.getMessage()
                                + "). Check the internet and the TV date and time.");
                    }
                });
            }
        }).start();
    }

    private void show(ArrayList<Item> items) {
        if (items.isEmpty()) {
            status.setText("No playable channels in this list");
            return;
        }
        Store.list = items;
        inChannels = true;
        labels.clear();
        for (int i = 0; i < items.size(); i++) labels.add((i + 1) + "    " + items.get(i).title);
        status.setText(items.size() + " channels. Press OK to watch. While watching, Up and Down change channel.");
        refresh(0);
    }

    private void play(int pos) {
        Intent i = new Intent(this, PlayerActivity.class);
        i.putExtra("idx", pos);
        i.putExtra("live", true);
        go(i);
    }

    @Override public void onBackPressed() {
        if (inChannels) showCats();
        else super.onBackPressed();
    }
}
