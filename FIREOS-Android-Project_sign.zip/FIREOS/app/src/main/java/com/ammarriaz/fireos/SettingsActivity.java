package com.ammarriaz.fireos;

import android.os.Bundle;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Switches and the few text fields FIREOS needs. Text is saved when you leave this screen. */
public class SettingsActivity extends BaseActivity {
    private EditText key, inv, pl;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.px(70), Ui.px(40), Ui.px(70), Ui.px(50));
        col.addView(Ui.text(this, "Settings", 52, Ui.EMBER, true));
        col.addView(toggle("Relaxed HTTPS (lets old TVs load lists and videos)", "relaxed"));
        col.addView(toggle("Animations (turn off if the TV feels slow)", "anim"));
        key = field(col, "YouTube API key (optional, gives the best search)", "AIza...", Prefs.ytKey());
        inv = field(col, "YouTube server address (leave empty to find one automatically)", "https://...", Prefs.inv());
        pl = field(col, "Your own IPTV playlist (.m3u link)", "http://.../list.m3u", Prefs.playlist());
        TextView about = Ui.text(this, "FIREOS 1.0, made by Ammar Riaz", 22, Ui.MUTED, false);
        about.setPadding(0, Ui.px(30), 0, 0);
        col.addView(about);
        sv.addView(col);
        setContentView(sv);
    }

    private View toggle(final String label, final String k) {
        final Button b = new Button(this);
        b.setTextColor(Ui.TEXT);
        b.setTextSize(TypedValue.COMPLEX_UNIT_PX, Ui.px(26));
        b.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        b.setBackgroundResource(R.drawable.bg_btn);
        b.setPadding(Ui.px(24), Ui.px(16), Ui.px(24), Ui.px(16));
        b.setText(label + ": " + (Prefs.flag(k, true) ? "ON" : "OFF"));
        b.setOnClickListener(v -> {
            boolean on = !Prefs.flag(k, true);
            Prefs.putFlag(k, on);
            b.setText(label + ": " + (on ? "ON" : "OFF"));
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, Ui.px(18), 0, 0);
        b.setLayoutParams(lp);
        return b;
    }

    private EditText field(LinearLayout col, String label, String hint, String value) {
        TextView l = Ui.text(this, label, 24, Ui.MUTED, false);
        l.setPadding(0, Ui.px(22), 0, Ui.px(8));
        col.addView(l);
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setHint(hint);
        e.setText(value);
        e.setTextColor(Ui.TEXT);
        e.setHintTextColor(0xFF6E6285);
        e.setTextSize(TypedValue.COMPLEX_UNIT_PX, Ui.px(28));
        e.setBackgroundResource(R.drawable.bg_input);
        e.setPadding(Ui.px(20), Ui.px(14), Ui.px(20), Ui.px(14));
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        col.addView(e, new LinearLayout.LayoutParams(-1, -2));
        return e;
    }

    @Override protected void onPause() {
        super.onPause();
        Prefs.put("ytkey", key.getText().toString().trim());
        Prefs.put("inv", inv.getText().toString().trim());
        Prefs.put("plurl", pl.getText().toString().trim());
    }
}
