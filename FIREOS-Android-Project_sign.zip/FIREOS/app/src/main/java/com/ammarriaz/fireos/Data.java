package com.ammarriaz.fireos;

import android.text.Html;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

/** Reads .m3u playlists (the format IPTV lists use). */
final class M3u {
    static ArrayList<Item> parse(String text, int max) {
        ArrayList<Item> out = new ArrayList<Item>();
        String name = null;
        for (String raw : text.split("\\r?\\n")) {
            String l = raw.trim();
            if (l.startsWith("#EXTINF")) {
                int i = l.lastIndexOf(',');
                name = i >= 0 ? l.substring(i + 1).trim() : "";
                if (name.length() == 0) name = "Channel";
            } else if (l.length() > 0 && l.charAt(0) != '#' && name != null) {
                if (l.startsWith("http") && !l.contains("youtube.com") && !l.contains("youtu.be")) {
                    out.add(new Item(name, l));
                }
                name = null;
                if (out.size() >= max) break;
            }
        }
        return out;
    }
}

/** YouTube search through the official API (if you add a key) or through Invidious servers. */
final class Yt {
    private static String norm(String s) {
        s = s.trim();
        if (s.length() == 0) return "";
        if (!s.startsWith("http")) s = "https://" + s;
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }

    static Item video(String id, String title) {
        Item it = new Item(title, null);
        it.yt = id;
        it.thumb = "https://i.ytimg.com/vi/" + id + "/mqdefault.jpg";
        return it;
    }

    /** Servers to try: yours from Settings, otherwise the last one that worked plus public ones. */
    static ArrayList<String> servers() {
        ArrayList<String> list = new ArrayList<String>();
        String mine = norm(Prefs.inv());
        if (mine.length() > 0) {
            list.add(mine);
            return list;
        }
        String ok = norm(Prefs.get("invok", ""));
        if (ok.length() > 0) list.add(ok);
        try {
            JSONArray a = new JSONArray(Net.get("https://api.invidious.io/instances.json"));
            for (int i = 0; i < a.length() && list.size() < 5; i++) {
                JSONObject o = a.getJSONArray(i).getJSONObject(1);
                String u = norm(o.optString("uri"));
                if ("https".equals(o.optString("type")) && o.optBoolean("api") && u.length() > 0 && !list.contains(u)) {
                    list.add(u);
                }
            }
        } catch (Exception e) {
            // use whatever we already have
        }
        return list;
    }

    /** Server used to stream a video (call from a background thread). */
    static String playBase() {
        ArrayList<String> s = servers();
        return s.isEmpty() ? "" : s.get(0);
    }

    /** Empty query means "popular videos". */
    static ArrayList<Item> search(String q) throws Exception {
        String key = Prefs.ytKey().trim();
        ArrayList<Item> r = new ArrayList<Item>();
        if (key.length() > 0) {
            String u = q.length() == 0
                    ? "https://www.googleapis.com/youtube/v3/videos?part=snippet&chart=mostPopular&maxResults=24&regionCode=US&key=" + key
                    : "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=24&q="
                    + URLEncoder.encode(q, "UTF-8") + "&key=" + key;
            JSONArray a = new JSONObject(Net.get(u)).getJSONArray("items");
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                JSONObject id = o.optJSONObject("id");
                String vid = id != null ? id.optString("videoId") : o.optString("id");
                if (vid.length() == 11) {
                    String title = o.getJSONObject("snippet").optString("title");
                    r.add(video(vid, Html.fromHtml(title).toString()));
                }
            }
            return r;
        }
        String path = q.length() == 0 ? "/api/v1/trending" : "/api/v1/search?type=video&q=" + URLEncoder.encode(q, "UTF-8");
        Exception last = null;
        for (String base : servers()) {
            try {
                JSONArray a = new JSONArray(Net.get(base + path));
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    String vid = o.optString("videoId");
                    if (vid.length() == 11) r.add(video(vid, o.optString("title")));
                }
                if (!r.isEmpty()) {
                    Prefs.put("invok", base);
                    return r;
                }
            } catch (Exception e) {
                last = e;
            }
        }
        throw last != null ? last : new IOException("No YouTube server answered");
    }
}
