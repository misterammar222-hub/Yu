package com.ammarriaz.fireos;

import android.os.Bundle;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Game menu plus the three games. Back leaves a game, then the menu. */
public class GamesActivity extends BaseActivity {
    private GameView game;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        menu();
    }

    private void menu() {
        FrameLayout root = new FrameLayout(this);
        root.setClipChildren(false);
        root.addView(new EmberView(this), new FrameLayout.LayoutParams(-1, -1));
        TextView t = Ui.text(this, "Games", 56, Ui.EMBER, true);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.LEFT);
        tp.setMargins(Ui.px(60), Ui.px(34), 0, 0);
        root.addView(t, tp);
        Fx.enter(t, 0);

        String[] names = {"Snake", "2048", "Pong"};
        String[] subs = {"Eat and grow", "Merge the tiles", "Up and Down vs CPU"};
        int[] top = {0xFF35C98A, 0xFFF0B429, 0xFF8E63E0};
        int[] bot = {0xFF16764F, 0xFFB26E0B, 0xFF4B2C8F};
        LinearLayout row = new LinearLayout(this);
        row.setClipChildren(false);
        row.setGravity(Gravity.CENTER);
        for (int i = 0; i < 3; i++) {
            final int n = i;
            Tile tile = new Tile(this, names[i], subs[i], top[i], bot[i], Icons.PAD);
            tile.setOnClickListener(v -> play(n));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.px(250), Ui.px(320));
            lp.setMargins(Ui.px(20), 0, Ui.px(20), 0);
            row.addView(tile, lp);
            Fx.enter(tile, 150 + i * 120);
        }
        root.addView(row, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));

        TextView hint = Ui.text(this, "In a game: arrows move, OK restarts, Back returns here", 22, Ui.MUTED, false);
        FrameLayout.LayoutParams hl = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        hl.setMargins(0, 0, 0, Ui.px(34));
        root.addView(hint, hl);
        setContentView(root);
        row.getChildAt(0).requestFocus();
    }

    private void play(int n) {
        game = n == 0 ? new SnakeView(this) : n == 1 ? new Game2048View(this) : new PongView(this);
        setContentView(game);
        game.start();
    }

    @Override public void onBackPressed() {
        if (game != null) {
            game.stop();
            game = null;
            menu();
        } else {
            super.onBackPressed();
        }
    }

    @Override protected void onPause() {
        super.onPause();
        if (game != null) game.stop();
    }

    @Override protected void onResume() {
        super.onResume();
        if (game != null) game.start();
    }
}
