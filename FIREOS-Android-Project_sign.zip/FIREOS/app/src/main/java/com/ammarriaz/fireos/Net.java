package com.ammarriaz.fireos;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.LruCache;
import android.widget.ImageView;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.security.cert.X509Certificate;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 * HTTP for Android 4.4: turns on TLS 1.2 (off by default before Android 5) and, when
 * "Relaxed HTTPS" is ON, skips certificate checks because old TVs lack today's root certificates.
 */
final class Net {
    private static final String UA = "Mozilla/5.0 (Linux; Android 4.4.4; FIREOS) AppleWebKit/537.36";
    private static SSLSocketFactory tls, relaxed;
    private static final HostnameVerifier ANY = new HostnameVerifier() {
        @Override public boolean verify(String host, SSLSession session) { return true; }
    };

    static {
        try {
            SSLContext a = context();
            a.init(null, null, null);
            tls = new Tls12(a.getSocketFactory());
            SSLContext b = context();
            b.init(null, new TrustManager[]{new X509TrustManager() {
                @Override public void checkClientTrusted(X509Certificate[] chain, String type) { }
                @Override public void checkServerTrusted(X509Certificate[] chain, String type) { }
                @Override public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
            }}, null);
            relaxed = new Tls12(b.getSocketFactory());
        } catch (Exception e) {
            // keep the platform defaults
        }
    }

    private static SSLContext context() throws Exception {
        try {
            return SSLContext.getInstance("TLSv1.2");
        } catch (Exception e) {
            return SSLContext.getInstance("TLS");
        }
    }

    /** Opens a connection and follows redirects (including http to https). Check getResponseCode() yourself. */
    static HttpURLConnection open(String url, String range) throws IOException {
        for (int i = 0; i < 6; i++) {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            if (c instanceof HttpsURLConnection) {
                HttpsURLConnection s = (HttpsURLConnection) c;
                if (Prefs.relaxed() && relaxed != null) {
                    s.setSSLSocketFactory(relaxed);
                    s.setHostnameVerifier(ANY);
                } else if (tls != null) {
                    s.setSSLSocketFactory(tls);
                }
            }
            c.setConnectTimeout(12000);
            c.setReadTimeout(25000);
            c.setInstanceFollowRedirects(false);
            c.setRequestProperty("User-Agent", UA);
            if (range != null) {
                c.setRequestProperty("Range", range);
                c.setRequestProperty("Accept-Encoding", "identity");
            }
            int code = c.getResponseCode();
            if (code >= 300 && code < 400) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null) throw new IOException("Redirect without an address");
                url = new URL(new URL(url), loc).toString();
                continue;
            }
            return c;
        }
        throw new IOException("Too many redirects");
    }

    static String get(String url) throws IOException {
        HttpURLConnection c = open(url, null);
        try {
            int code = c.getResponseCode();
            if (code != 200) throw new IOException("HTTP " + code);
            InputStream in = c.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0 && out.size() < 8000000) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } finally {
            c.disconnect();
        }
    }

    private static final class Tls12 extends SSLSocketFactory {
        private final SSLSocketFactory d;

        Tls12(SSLSocketFactory d) { this.d = d; }

        @Override public String[] getDefaultCipherSuites() { return d.getDefaultCipherSuites(); }
        @Override public String[] getSupportedCipherSuites() { return d.getSupportedCipherSuites(); }
        @Override public Socket createSocket(Socket s, String h, int p, boolean auto) throws IOException { return fix(d.createSocket(s, h, p, auto)); }
        @Override public Socket createSocket(String h, int p) throws IOException { return fix(d.createSocket(h, p)); }
        @Override public Socket createSocket(String h, int p, InetAddress la, int lp) throws IOException { return fix(d.createSocket(h, p, la, lp)); }
        @Override public Socket createSocket(InetAddress h, int p) throws IOException { return fix(d.createSocket(h, p)); }
        @Override public Socket createSocket(InetAddress h, int p, InetAddress la, int lp) throws IOException { return fix(d.createSocket(h, p, la, lp)); }

        private Socket fix(Socket s) {
            if (s instanceof SSLSocket) {
                try {
                    ((SSLSocket) s).setEnabledProtocols(new String[]{"TLSv1", "TLSv1.1", "TLSv1.2"});
                } catch (Exception e) {
                    // ignore
                }
            }
            return s;
        }
    }
}

/** Loads thumbnails in the background with a small memory cache. */
final class Img {
    private static final LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>(8 * 1024 * 1024) {
        @Override protected int sizeOf(String key, Bitmap b) { return b.getByteCount(); }
    };
    private static final ExecutorService pool = Executors.newFixedThreadPool(3);

    static void load(final ImageView v, final String url) {
        v.setTag(url);
        v.setAlpha(1f);
        if (url == null) {
            v.setImageDrawable(null);
            return;
        }
        Bitmap hit = cache.get(url);
        if (hit != null) {
            v.setImageBitmap(hit);
            return;
        }
        v.setImageDrawable(null);
        pool.execute(() -> {
            try {
                HttpURLConnection c = Net.open(url, null);
                try {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inPreferredConfig = Bitmap.Config.RGB_565;
                    final Bitmap bm = BitmapFactory.decodeStream(c.getInputStream(), null, o);
                    if (bm == null) return;
                    cache.put(url, bm);
                    v.post(() -> {
                        if (url.equals(v.getTag())) {
                            v.setImageBitmap(bm);
                            v.setAlpha(0f);
                            v.animate().alpha(1f).setDuration(250).start();
                        }
                    });
                } finally {
                    c.disconnect();
                }
            } catch (Exception e) {
                // thumbnail stays empty
            }
        });
    }
}

/**
 * Tiny local web server so the TV's video player can stream YouTube videos through our own
 * (certificate-tolerant) connection instead of its own old HTTPS stack.
 */
final class LocalProxy {
    private static ServerSocket server;

    static synchronized String wrap(String target) {
        try {
            if (server == null) {
                server = new ServerSocket(0, 8, InetAddress.getByName("127.0.0.1"));
                Thread t = new Thread(() -> {
                    while (true) {
                        try {
                            final Socket s = server.accept();
                            new Thread(() -> serve(s)).start();
                        } catch (IOException e) {
                            return;
                        }
                    }
                });
                t.setDaemon(true);
                t.start();
            }
            return "http://127.0.0.1:" + server.getLocalPort() + "/p?u=" + URLEncoder.encode(target, "UTF-8");
        } catch (Exception e) {
            return target;
        }
    }

    private static void serve(Socket s) {
        try {
            s.setSoTimeout(60000);
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), "ISO-8859-1"));
            String req = in.readLine(), line, range = null;
            while ((line = in.readLine()) != null && line.length() > 0) {
                if (line.regionMatches(true, 0, "Range:", 0, 6)) range = line.substring(6).trim();
            }
            if (req == null) return;
            int a = req.indexOf("u=") + 2, b = req.indexOf(' ', a);
            HttpURLConnection c = Net.open(URLDecoder.decode(req.substring(a, b), "UTF-8"), range);
            int code = c.getResponseCode();
            StringBuilder head = new StringBuilder("HTTP/1.1 " + code
                    + (code == 206 ? " Partial Content" : code == 200 ? " OK" : " Error") + "\r\n");
            String[] keep = {"Content-Type", "Content-Length", "Content-Range", "Accept-Ranges"};
            for (String k : keep) {
                String v = c.getHeaderField(k);
                if (v != null) head.append(k).append(": ").append(v).append("\r\n");
            }
            head.append("Connection: close\r\n\r\n");
            OutputStream out = s.getOutputStream();
            out.write(head.toString().getBytes("ISO-8859-1"));
            InputStream src = code >= 400 ? c.getErrorStream() : c.getInputStream();
            if (src != null) {
                byte[] buf = new byte[16384];
                int n;
                while ((n = src.read(buf)) > 0) out.write(buf, 0, n);
            }
            out.flush();
        } catch (Exception e) {
            // the player closed the connection (seeking) or the server failed
        } finally {
            try {
                s.close();
            } catch (Exception e) {
                // ignore
            }
        }
    }
}
