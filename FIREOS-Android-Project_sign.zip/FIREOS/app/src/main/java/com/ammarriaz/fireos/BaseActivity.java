package com.ammarriaz.fireos;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;

/** Shared setup: screen scaling, keep-awake, and the slide/fade transitions between screens. */
public abstract class BaseActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    void go(Class<?> c) {
        go(new Intent(this, c));
    }

    void go(Intent i) {
        startActivity(i);
        if (Prefs.anim()) overridePendingTransition(R.anim.slide_in, R.anim.fade_out);
    }

    @Override public void finish() {
        super.finish();
        if (Prefs.anim()) overridePendingTransition(R.anim.fade_in, R.anim.slide_out);
    }
}
