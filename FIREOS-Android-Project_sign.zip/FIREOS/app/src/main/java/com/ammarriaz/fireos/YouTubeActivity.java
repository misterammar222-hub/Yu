package com.ammarriaz.fireos;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

/** Search YouTube, browse popular videos, and play them inside FIREOS. */
public class YouTubeActivity extends BaseActivity {
    private final ArrayList<Item> items = new ArrayList<Item>();
    private GridView grid;
    private EditText box;
    private TextView status;
    private BaseAdapter ad;
    private int req;
    private boolean busy;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(Ui.px(60), Ui.px(36), Ui.px(60), Ui.px(24));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(Ui.text(this, "YouTube", 52, 0xFFFF5A45, true));
        box = new EditText(this);
        box.setSingleLine(true);
        box.setHint("Press OK to type, then choose Search");
        box.setHintTextColor(0xFF6E6285);
        box.setTextColor(Ui.TEXT);
        box.setTextSize(TypedValue.COMPLEX_UNIT_PX, Ui.px(28));
        box.setBackgroundResource(R.drawable.bg_input);
        box.setPadding(Ui.px(20), Ui.px(12), Ui.px(20), Ui.px(12));
        box.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        box.setOnEditorActionListener((tv, action, ev) -> {
            hideKeyboard();
            search(box.getText().toString().trim());
            return true;
        });
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(0, -2, 1f);
        bl.setMargins(Ui.px(36), 0, 0, 0);
        head.addView(box, bl);
        root.addView(head);

        status = Ui.text(this, "", 24, Ui.MUTED, false);
        status.setPadding(0, Ui.px(10), 0, Ui.px(10));
        root.addView(status);

        grid = new GridView(this);
        grid.setNumColumns(4);
        grid.setHorizontalSpacing(Ui.px(20));
        grid.setVerticalSpacing(Ui.px(20));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(R.drawable.sel_ring);
        grid.setDrawSelectorOnTop(true);
        grid.setVerticalScrollBarEnabled(false);
        grid.setPadding(Ui.px(6), Ui.px(6), Ui.px(6), Ui.px(6));
        grid.setClipToPadding(false);
        ad = new VidAdapter();
        grid.setAdapter(ad);
        grid.setOnItemClickListener((parent, view, pos, id) -> open(items.get(pos)));
        root.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
        search("");
    }

    private void hideKeyboard() {
        InputMethodManager m = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (m != null) m.hideSoftInputFromWindow(box.getWindowToken(), 0);
    }

    private void search(final String q) {
        final int my = ++req;
        status.setText(q.length() == 0 ? "Loading popular videos..." : "Searching for " + q + "...");
        new Thread(() -> {
            try {
                final ArrayList<Item> r = Yt.search(q);
                runOnUiThread(() -> {
                    if (my != req || isFinishing()) return;
                    items.clear();
                    items.addAll(r);
                    ad.notifyDataSetChanged();
                    grid.setSelection(0);
                    status.setText(q.length() == 0 ? "Popular right now" : "Results for " + q);
                    grid.requestFocus();
                });
            } catch (final Exception e) {
                runOnUiThread(() -> {
                    if (my == req && !isFinishing()) {
                        status.setText("YouTube is not reachable (" + e.getMessage()
                                + "). Add a server or API key in Settings.");
                    }
                });
            }
        }).start();
    }

    private void open(final Item it) {
        if (busy) return;
        busy = true;
        status.setText("Finding a stream...");
        new Thread(() -> {
            final String base = Yt.playBase();
            runOnUiThread(() -> {
                busy = false;
                if (isFinishing()) return;
                if (base.length() == 0) {
                    Toast.makeText(this, "No video server found, opening the YouTube app instead", Toast.LENGTH_LONG).show();
                    PlayerActivity.external(this, it.yt);
                    return;
                }
                it.url = LocalProxy.wrap(base + "/latest_version?id=" + it.yt + "&itag=18&local=true");
                Store.list = new ArrayList<Item>();
                Store.list.add(it);
                Intent i = new Intent(this, PlayerActivity.class);
                i.putExtra("idx", 0);
                i.putExtra("live", false);
                go(i);
                status.setText("");
            });
        }).start();
    }

    private class VidAdapter extends BaseAdapter {
        @Override public int getCount() { return items.size(); }
        @Override public Object getItem(int i) { return items.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override public View getView(int i, View v, ViewGroup parent) {
            LinearLayout card = (LinearLayout) v;
            if (card == null) {
                card = new LinearLayout(YouTubeActivity.this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(Ui.px(5), Ui.px(5), Ui.px(5), Ui.px(5));
                card.setLayoutParams(new AbsListView.LayoutParams(-1, Ui.px(250)));
                ImageView img = new ImageView(YouTubeActivity.this);
                img.setScaleType(ImageView.ScaleType.CENTER_CROP);
                img.setBackgroundColor(Ui.PANEL);
                card.addView(img, new LinearLayout.LayoutParams(-1, Ui.px(158)));
                TextView t = Ui.text(YouTubeActivity.this, "", 22, Ui.TEXT, false);
                t.setMaxLines(2);
                t.setEllipsize(TextUtils.TruncateAt.END);
                t.setPadding(Ui.px(4), Ui.px(8), Ui.px(4), 0);
                card.addView(t);
            }
            Item it = items.get(i);
            ((TextView) card.getChildAt(1)).setText(it.title);
            Img.load((ImageView) card.getChildAt(0), it.thumb);
            return card;
        }
    }
}
