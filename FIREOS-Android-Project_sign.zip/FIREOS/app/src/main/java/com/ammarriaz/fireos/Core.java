package com.ammarriaz.fireos;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.TextView;
import java.util.ArrayList;

/** One playable thing: a TV channel or a YouTube video. */
final class Item {
    String title, url, yt, thumb;

    Item(String title, String url) {
        this.title = title;
        this.url = url;
    }
}

/** The list the player is working through (a channel list, or a single video). */
final class Store {
    static ArrayList<Item> list = new ArrayList<Item>();
}

/** Tiny settings store. */
final class Prefs {
    private static SharedPreferences sp;

    static void init(Context c) {
        sp = c.getSharedPreferences("fireos", Context.MODE_PRIVATE);
    }

    static String get(String k, String d) { return sp == null ? d : sp.getString(k, d); }
    static void put(String k, String v) { if (sp != null) sp.edit().putString(k, v).apply(); }
    static boolean flag(String k, boolean d) { return sp == null ? d : sp.getBoolean(k, d); }
    static void putFlag(String k, boolean v) { if (sp != null) sp.edit().putBoolean(k, v).apply(); }

    static String ytKey() { return get("ytkey", ""); }
    static String inv() { return get("inv", ""); }
    static String playlist() { return get("plurl", ""); }
    static boolean relaxed() { return flag("relaxed", true); }
    static boolean anim() { return flag("anim", true); }
}

/** Colours and screen scaling. px() makes every layout look the same on 720p and 1080p TVs. */
final class Ui {
    static final int BG = 0xFF15101E, PANEL = 0xFF221A30, EMBER = 0xFFFF6A1A, AMBER = 0xFFFFB347,
            TEXT = 0xFFF1ECFA, MUTED = 0xFFA89BBD;
    private static float k = 1f;

    static void init(Activity a) {
        DisplayMetrics m = new DisplayMetrics();
        a.getWindowManager().getDefaultDisplay().getMetrics(m);
        k = Math.max(0.5f, Math.min(m.widthPixels, m.heightPixels) / 720f);
    }

    static int px(float v) { return Math.round(v * k); }

    static TextView text(Context c, String s, float size, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, px(size));
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }
}

/** Animation helpers (all switch off when Animations is OFF in Settings). */
final class Fx {
    /** Grow the view when it gets D-pad focus. */
    static void pop(View v) {
        v.setOnFocusChangeListener((view, focused) -> {
            float s = focused ? 1.1f : 1f;
            if (Prefs.anim()) {
                view.animate().scaleX(s).scaleY(s).setDuration(160)
                        .setInterpolator(new DecelerateInterpolator()).start();
            } else {
                view.setScaleX(s);
                view.setScaleY(s);
            }
        });
    }

    /** Fade and slide a view up into place. */
    static void enter(View v, long delay) {
        if (!Prefs.anim()) return;
        v.setAlpha(0f);
        v.setTranslationY(Ui.px(46));
        v.animate().alpha(1f).translationY(0f).setStartDelay(delay).setDuration(480)
                .setInterpolator(new DecelerateInterpolator(1.6f)).start();
    }
}
