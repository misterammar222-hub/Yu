package com.ammarriaz.fireos;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Random;

/** Vector icons drawn with the Canvas, so no image files are needed and they stay sharp on any screen. */
final class Icons {
    static final int PLAY = 0, TV = 1, PAD = 2, GEAR = 3;

    static void draw(Canvas c, int type, float cx, float cy, float s, Paint p, int cut) {
        RectF r = new RectF();
        p.setColor(0xFFFFFFFF);
        p.setStyle(Paint.Style.FILL);
        switch (type) {
            case PLAY: {
                r.set(cx - s * 1.3f, cy - s * 0.9f, cx + s * 1.3f, cy + s * 0.9f);
                c.drawRoundRect(r, s * 0.5f, s * 0.5f, p);
                Path tri = new Path();
                tri.moveTo(cx - s * 0.32f, cy - s * 0.5f);
                tri.lineTo(cx - s * 0.32f, cy + s * 0.5f);
                tri.lineTo(cx + s * 0.52f, cy);
                tri.close();
                p.setColor(cut);
                c.drawPath(tri, p);
                break;
            }
            case TV: {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(s * 0.17f);
                p.setStrokeCap(Paint.Cap.ROUND);
                r.set(cx - s * 1.2f, cy - s * 0.9f, cx + s * 1.2f, cy + s * 0.6f);
                c.drawRoundRect(r, s * 0.22f, s * 0.22f, p);
                c.drawLine(cx - s * 0.55f, cy + s * 1.0f, cx + s * 0.55f, cy + s * 1.0f, p);
                p.setStyle(Paint.Style.FILL);
                Path tri = new Path();
                tri.moveTo(cx - s * 0.22f, cy - s * 0.45f);
                tri.lineTo(cx - s * 0.22f, cy + s * 0.15f);
                tri.lineTo(cx + s * 0.32f, cy - s * 0.15f);
                tri.close();
                c.drawPath(tri, p);
                break;
            }
            case PAD: {
                r.set(cx - s * 1.3f, cy - s * 0.7f, cx + s * 1.3f, cy + s * 0.7f);
                c.drawRoundRect(r, s * 0.6f, s * 0.6f, p);
                p.setColor(cut);
                c.drawRect(cx - s * 0.97f, cy - s * 0.12f, cx - s * 0.37f, cy + s * 0.12f, p);
                c.drawRect(cx - s * 0.79f, cy - s * 0.3f, cx - s * 0.55f, cy + s * 0.3f, p);
                c.drawCircle(cx + s * 0.5f, cy - s * 0.12f, s * 0.17f, p);
                c.drawCircle(cx + s * 0.85f, cy + s * 0.12f, s * 0.17f, p);
                break;
            }
            default: {
                c.drawCircle(cx, cy, s * 0.75f, p);
                for (int i = 0; i < 8; i++) {
                    c.save();
                    c.rotate(i * 45f, cx, cy);
                    c.drawRect(cx - s * 0.18f, cy - s * 1.1f, cx + s * 0.18f, cy - s * 0.6f, p);
                    c.restore();
                }
                p.setColor(cut);
                c.drawCircle(cx, cy, s * 0.3f, p);
                break;
            }
        }
        p.setStrokeCap(Paint.Cap.BUTT);
    }
}

/** A home-screen tile: gradient card, icon, label, and an amber ring when focused. */
final class Tile extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final String label, sub;
    private final int top, bot, icon;
    private LinearGradient body, shine;

    Tile(Context c, String label, String sub, int top, int bot, int icon) {
        super(c);
        this.label = label;
        this.sub = sub;
        this.top = top;
        this.bot = bot;
        this.icon = icon;
        setFocusable(true);
        setClickable(true);
        Fx.pop(this);
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        body = new LinearGradient(0, 0, 0, h, top, bot, Shader.TileMode.CLAMP);
        shine = new LinearGradient(0, 0, 0, h * 0.55f, 0x40FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP);
    }

    @Override protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        float rad = Ui.px(24), m = Ui.px(5);
        r.set(m, m, w - m, h - m);
        p.setStyle(Paint.Style.FILL);
        p.setShader(body);
        c.drawRoundRect(r, rad, rad, p);
        p.setShader(shine);
        c.drawRoundRect(r, rad, rad, p);
        p.setShader(null);
        Icons.draw(c, icon, w / 2f, h * 0.36f, Ui.px(46), p, bot);
        p.setStyle(Paint.Style.FILL);
        p.setTextAlign(Paint.Align.CENTER);
        p.setColor(0xFFFFFFFF);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(Ui.px(36));
        c.drawText(label, w / 2f, h * 0.73f, p);
        p.setTypeface(Typeface.DEFAULT);
        p.setTextSize(Ui.px(21));
        p.setColor(0xD8FFFFFF);
        c.drawText(sub, w / 2f, h * 0.73f + Ui.px(36), p);
        if (isFocused()) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Ui.px(6));
            p.setColor(0xFFFFB347);
            c.drawRoundRect(r, rad, rad, p);
        }
    }
}

/** Animated background: a warm glow with embers drifting upward. Cheap enough for old TVs. */
final class EmberView extends View {
    private static final int N = 34;
    private final float[] x = new float[N], y = new float[N], v = new float[N], s = new float[N], ph = new float[N];
    private final Random rnd = new Random();
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), bg = new Paint(), glow = new Paint();
    private final boolean live = Prefs.anim();
    private long last;

    EmberView(Context c) {
        super(c);
        for (int i = 0; i < N; i++) reset(i, true);
    }

    private void reset(int i, boolean anywhere) {
        x[i] = rnd.nextFloat();
        y[i] = anywhere ? rnd.nextFloat() : 1.02f;
        v[i] = 0.04f + rnd.nextFloat() * 0.10f;
        s[i] = 1.5f + rnd.nextFloat() * 4f;
        ph[i] = rnd.nextFloat() * 6.28f;
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        bg.setShader(new LinearGradient(0, 0, 0, h, 0xFF150F20, 0xFF2B1018, Shader.TileMode.CLAMP));
        glow.setShader(new RadialGradient(w / 2f, h * 1.05f, w * 0.65f, 0x55FF6A1A, 0x00FF6A1A, Shader.TileMode.CLAMP));
    }

    @Override protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        c.drawRect(0, 0, w, h, bg);
        c.drawRect(0, 0, w, h, glow);
        if (!live) return;
        long now = SystemClock.uptimeMillis();
        float dt = last == 0 ? 0.016f : Math.min(50, now - last) / 1000f;
        last = now;
        for (int i = 0; i < N; i++) {
            y[i] -= v[i] * dt;
            if (y[i] < -0.03f) reset(i, false);
            float px = x[i] * w + (float) Math.sin(ph[i] + now / 900.0) * Ui.px(14);
            float a = Math.max(0f, Math.min(1f, y[i] * 1.1f));
            p.setColor(Color.argb((int) (a * 200), 255, 120 + (int) (a * 80), 40));
            c.drawCircle(px, y[i] * h, Ui.px(s[i]), p);
        }
        postInvalidateOnAnimation();
    }
}

/** Adapter for plain one-line lists (categories, channels). */
final class TextAdapter extends BaseAdapter {
    private final Context ctx;
    private final ArrayList<String> data;

    TextAdapter(Context ctx, ArrayList<String> data) {
        this.ctx = ctx;
        this.data = data;
    }

    @Override public int getCount() { return data.size(); }
    @Override public Object getItem(int i) { return data.get(i); }
    @Override public long getItemId(int i) { return i; }

    @Override public View getView(int i, View v, ViewGroup parent) {
        TextView t = (TextView) v;
        if (t == null) {
            t = new TextView(ctx);
            t.setTextSize(TypedValue.COMPLEX_UNIT_PX, Ui.px(30));
            t.setTextColor(Ui.TEXT);
            t.setSingleLine(true);
            t.setEllipsize(TextUtils.TruncateAt.END);
            t.setPadding(Ui.px(28), Ui.px(17), Ui.px(28), Ui.px(17));
            t.setLayoutParams(new AbsListView.LayoutParams(-1, -2));
        }
        t.setText(data.get(i));
        return t;
    }
}
