package com.ammarriaz.fireos;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

/**
 * Full-screen player for live channels and YouTube videos.
 * Live: Up/Down (or CH+/CH-) change channel, OK shows the name.
 * Video: Left/Right jump 10 seconds, OK pauses or plays.
 */
public class PlayerActivity extends BaseActivity {
    private VideoView vv;
    private ProgressBar spin;
    private TextView banner, msg;
    private Bar bar;
    private int idx, fails;
    private boolean live, failed, paused;
    private final Handler hd = new Handler();

    private final Runnable hideBanner = new Runnable() {
        @Override public void run() { banner.animate().alpha(0f).setDuration(400).start(); }
    };
    private final Runnable nextCh = new Runnable() {
        @Override public void run() { play(idx + 1); }
    };
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!live && vv != null) {
                int d = vv.getDuration();
                if (d > 0) bar.set(vv.getCurrentPosition() / (float) d);
            }
            hd.postDelayed(this, 500);
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        live = getIntent().getBooleanExtra("live", true);
        idx = getIntent().getIntExtra("idx", 0);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        vv = new VideoView(this);
        root.addView(vv, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        spin = new ProgressBar(this);
        root.addView(spin, new FrameLayout.LayoutParams(Ui.px(90), Ui.px(90), Gravity.CENTER));

        banner = Ui.text(this, "", 34, 0xFFFFFFFF, true);
        banner.setBackgroundColor(0xC015101E);
        banner.setPadding(Ui.px(26), Ui.px(14), Ui.px(26), Ui.px(14));
        banner.setAlpha(0f);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.LEFT);
        bp.setMargins(Ui.px(50), Ui.px(40), 0, 0);
        root.addView(banner, bp);

        msg = Ui.text(this, "", 34, 0xFFFFFFFF, true);
        msg.setGravity(Gravity.CENTER);
        msg.setVisibility(View.GONE);
        root.addView(msg, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));

        bar = new Bar(this);
        bar.setVisibility(live ? View.GONE : View.VISIBLE);
        root.addView(bar, new FrameLayout.LayoutParams(-1, Ui.px(8), Gravity.BOTTOM));
        setContentView(root);

        vv.setOnPreparedListener(mp -> {
            spin.setVisibility(View.GONE);
            fails = 0;
        });
        vv.setOnErrorListener((mp, what, extra) -> {
            fail();
            return true;
        });
        vv.setOnCompletionListener(mp -> {
            if (live) play(idx + 1);
            else finish();
        });
        vv.setOnInfoListener((mp, what, extra) -> {
            if (what == MediaPlayer.MEDIA_INFO_BUFFERING_START) {
                spin.setVisibility(View.VISIBLE);
            } else if (what == MediaPlayer.MEDIA_INFO_BUFFERING_END
                    || what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START) {
                spin.setVisibility(View.GONE);
            }
            return true;
        });
        play(idx);
    }

    private void play(int i) {
        if (Store.list.isEmpty()) {
            finish();
            return;
        }
        idx = (i + Store.list.size()) % Store.list.size();
        Item it = Store.list.get(idx);
        failed = false;
        msg.setVisibility(View.GONE);
        spin.setVisibility(View.VISIBLE);
        showBanner(live ? "CH " + (idx + 1) + "    " + it.title : it.title);
        vv.stopPlayback();
        if (it.url == null) {
            fail();
            return;
        }
        vv.setVideoURI(Uri.parse(it.url));
        vv.start();
    }

    private void fail() {
        spin.setVisibility(View.GONE);
        if (live && Store.list.size() > 1 && fails++ < 8) {
            showBanner("Channel offline, trying the next one...");
            hd.removeCallbacks(nextCh);
            hd.postDelayed(nextCh, 1500);
            return;
        }
        Item it = Store.list.get(idx);
        msg.setText(it.yt != null
                ? "Could not play this video here.\nPress OK to open it in the YouTube app."
                : "This channel is not available.\nPress Up or Down to try another.");
        msg.setVisibility(View.VISIBLE);
        failed = true;
    }

    private void showBanner(String s) {
        banner.setText(s);
        banner.setVisibility(View.VISIBLE);
        banner.setAlpha(0f);
        banner.animate().alpha(1f).setDuration(250).start();
        hd.removeCallbacks(hideBanner);
        hd.postDelayed(hideBanner, 3500);
    }

    private void seek(int ms) {
        int d = vv.getDuration();
        if (d <= 0) return;
        vv.seekTo(Math.max(0, Math.min(d, vv.getCurrentPosition() + ms)));
        showBanner((ms > 0 ? "+" : "-") + Math.abs(ms / 1000) + " s");
    }

    @Override public boolean onKeyDown(int k, KeyEvent e) {
        switch (k) {
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_CHANNEL_UP:
            case KeyEvent.KEYCODE_PAGE_UP:
                if (live) {
                    play(idx - 1);
                    return true;
                }
                break;
            case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_CHANNEL_DOWN:
            case KeyEvent.KEYCODE_PAGE_DOWN:
                if (live) {
                    play(idx + 1);
                    return true;
                }
                break;
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_MEDIA_REWIND:
                if (!live) {
                    seek(-10000);
                    return true;
                }
                break;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
                if (!live) {
                    seek(10000);
                    return true;
                }
                break;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case KeyEvent.KEYCODE_MEDIA_PLAY:
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (failed) {
                    external(this, Store.list.get(idx).yt);
                    return true;
                }
                if (!live) {
                    if (vv.isPlaying()) vv.pause();
                    else vv.start();
                }
                showBanner(Store.list.get(idx).title);
                return true;
            default:
                break;
        }
        return super.onKeyDown(k, e);
    }

    /** Fallback: hand a YouTube video to the YouTube app (or a browser) if one is installed. */
    static void external(Activity a, String id) {
        if (id == null) return;
        try {
            a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:" + id)));
        } catch (Exception e) {
            try {
                a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=" + id)));
            } catch (Exception x) {
                Toast.makeText(a, "No YouTube app or browser found on this TV", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override protected void onResume() {
        super.onResume();
        hd.post(tick);
        if (paused) {
            paused = false;
            play(idx);
        }
    }

    @Override protected void onPause() {
        super.onPause();
        paused = true;
        hd.removeCallbacks(tick);
        hd.removeCallbacks(nextCh);
        vv.stopPlayback();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        hd.removeCallbacksAndMessages(null);
        vv.stopPlayback();
    }

    /** Thin progress bar along the bottom for videos. */
    private static final class Bar extends View {
        private final Paint p = new Paint();
        private float f;

        Bar(Context c) { super(c); }

        void set(float v) {
            f = v;
            invalidate();
        }

        @Override protected void onDraw(Canvas c) {
            p.setColor(0x66FFFFFF);
            c.drawRect(0, 0, getWidth(), getHeight(), p);
            p.setColor(0xFFFF6A1A);
            c.drawRect(0, 0, getWidth() * f, getHeight(), p);
        }
    }
}
