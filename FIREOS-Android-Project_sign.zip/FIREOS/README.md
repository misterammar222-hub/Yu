# FIREOS 1.0 (made by Ammar Riaz)

A TV "operating system" app for Android 4.4 and newer: animated home screen, YouTube,
free IPTV channels (iptv-org lists) and three games (Snake, 2048, Pong).

* Pure Java, no libraries, no native code -> runs on every CPU (ARM, x86, MIPS).
* Built for old TVs: draws everything itself, small memory use, animations can be switched off.
* Remote friendly: arrows move, OK selects, Back goes back.

## Build the APK (Android Studio)

1. Install Android Studio. Choose File > Open and pick this FIREOS folder.
2. Wait for the Gradle sync (needs internet once). Accept any prompt to install
   Android SDK 34 or to update Gradle / the Android Gradle Plugin.
3. Quick test build: Build > Build Bundle(s) / APK(s) > Build APK(s).
   Result: app/build/outputs/apk/debug/app-debug.apk (signed with the debug key, installs fine).
4. Release build: Build > Generate Signed App Bundle / APK > APK > Create new keystore
   (keep the .jks file and passwords safe) > choose "release" > Finish.
   Result: app/release/app-release.apk

## Install on the TV

* On the TV: Settings > Security > Unknown sources = ON.
* Copy the APK to a USB stick and open it with a file manager on the TV, or from a PC run:
  `adb connect TV_IP_ADDRESS` then `adb install -r app-release.apk`

## Using FIREOS

* **Live TV**: pick a list (News, Sports, Movies, a country...), pick a channel. While watching,
  Up/Down (or CH+/CH-) change channel. Dead channels are skipped automatically.
  Many free streams go offline now and then; that is normal.
* **YouTube**: shows popular videos, press OK on the search box to type. Videos play inside FIREOS
  through a public Invidious server, found automatically. In Settings you can add your own
  server and/or a free YouTube Data API key for better search. If a video cannot play, press OK
  on the error screen to open it in the YouTube app instead.
* **Games**: Snake, 2048, Pong.
* **Settings**: "Relaxed HTTPS" (ON by default) lets Android 4.4 connect to sites that use
  newer security certificates. It skips certificate checks inside FIREOS only. Turn it OFF if you
  only use sites your TV already trusts. "Animations" OFF makes everything lighter.

## If something does not load

1. Check the TV date and time (wrong dates break secure connections).
2. Keep "Relaxed HTTPS" ON.
3. Use your own playlist link in Settings (an http:// link works best on very old TVs).
4. YouTube depends on third-party servers; set a different server in Settings if one stops working.

## Make FIREOS the TV home screen (optional)

In app/src/main/AndroidManifest.xml, remove the comment markers around the second
`<intent-filter>` (the one with HOME). Rebuild, then press Home on the TV and choose FIREOS.
To go back, use Settings > Apps > FIREOS > Clear defaults.

## Project layout

app/src/main/java/com/ammarriaz/fireos/
* MainActivity: home screen. LiveTvActivity, PlayerActivity, YouTubeActivity, GamesActivity, SettingsActivity.
* Views.java: tiles, icons, ember background. GameViews.java: the games.
* Net.java: web access for old TVs (TLS 1.2, thumbnails, local video proxy). Data.java: playlists and YouTube search.
